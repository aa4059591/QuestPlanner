package org.example.model;

import java.util.ArrayList;
import java.util.List;

public class Player {
    private String nickname;
    private String password;
    private int level = 1;
    private int exp = 0;
    private List<Quest> quests = new ArrayList<>();

    public Player() {}
    public Player(String nickname, String password) {
        this.nickname = nickname;
        this.password = password;
    }

    public boolean gainExp(int amount) {
        this.exp += amount;
        if (this.exp >= level * 100) {
            this.exp -= (level * 100);
            this.level++;
            return true; // 레벨업 발생
        }
        return false;
    }

    // Getters/Setters
    public String getNickname() { return nickname; }
    public String getPassword() { return password; }
    public int getLevel() { return level; }
    public int getExp() { return exp; }
    public List<Quest> getQuests() { return quests; }
}