package org.example.ui;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.formdev.flatlaf.FlatDarkLaf;
import org.example.model.GameData;
import org.example.model.Player;
import org.example.model.Quest;
import org.example.model.SaveData;
import org.example.network.SocialClient;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class MainFrame extends JFrame {

    private Player player;
    private List<Quest> quests;
    private String SAVE_FILE;

    private ObjectMapper mapper = new ObjectMapper()
            .enable(SerializationFeature.INDENT_OUTPUT)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

    private LocalDate currentDate = LocalDate.now();

    private Map<String, SocialClient> activeClients = new HashMap<>();
    private Map<String, Map<String, GameData>> multiRoomMembers = new HashMap<>();
    private List<String> roomCodesList = new ArrayList<>();
    private int currentRoomIndex = -1;

    private JPanel topSplitPanel;
    private JPanel myPanel;
    private JPanel guildContainer;

    private JLabel statusLabel;
    private JLabel totalCompletedLabel;
    private JProgressBar expBar;
    private JLabel imageLabel;
    private JPanel partyPanel;
    private JLabel guildNameLabel;
    private JLabel dateLabel;
    private JPanel todoPanel;
    private JPanel completedPanel;
    private JLabel summaryLabel;
    private JButton btnRebirth;

    public MainFrame() {
        if (!doLogin()) {
            System.exit(0);
        }
        setupUI();
        initSavedRooms();
        renderQuests();
    }

    private boolean doLogin() {
        LoginDialog login = new LoginDialog();
        login.setVisible(true);
        if (login.getNickname() == null) return false;

        this.SAVE_FILE = login.getNickname() + "_data.json";

        if (login.isNewUser()) {
            this.player = new Player(login.getNickname());
            this.quests = new ArrayList<>();
            saveGameData();
        } else {
            try {
                SaveData data = mapper.readValue(new File(SAVE_FILE), SaveData.class);
                this.player = data.getPlayer();
                this.quests = data.getQuests();
                if (player.getCharacterType() == null) player.setCharacterType("EGG");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "데이터 구조가 변경되어 기존 데이터를 불러올 수 없습니다.\n해당 계정 파일을 삭제 후 새로 생성해주세요.", "데이터 충돌 오류", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        return true;
    }

    private void saveGameData() {
        try {
            SaveData data = new SaveData(player, quests);
            mapper.writeValue(new File(SAVE_FILE), data);
        } catch (IOException e) { e.printStackTrace(); }
    }

    private boolean isHost(String code) {
        String name = player.getJoinedRooms().get(code);
        return name != null && name.endsWith(" (방장)");
    }

    private void initSavedRooms() {
        if (!player.getJoinedRooms().isEmpty()) {
            roomCodesList.addAll(player.getJoinedRooms().keySet());
            List<String> disbandedCodes = new ArrayList<>();

            for (String code : roomCodesList) {
                int status = connectToRoom(code, player.getJoinedRooms().get(code), "RECONNECT", isHost(code));
                // ✨ 오프라인 동안 방이 폭파되었다면 리스트에 담아둡니다.
                if (status == -2) {
                    disbandedCodes.add(code);
                }
            }

            // ✨ 로그인 직후, 없어진 방들을 깔끔하게 청소하고 알림을 띄웁니다!
            if (!disbandedCodes.isEmpty()) {
                for (String code : disbandedCodes) {
                    String name = player.getJoinedRooms().get(code).replace(" (방장)", "");
                    JOptionPane.showMessageDialog(this, "오프라인 동안 [" + name + "] 길드가 해산되었습니다.");
                    player.getJoinedRooms().remove(code);
                    roomCodesList.remove(code);
                }
                saveGameData();
            }

            if (!roomCodesList.isEmpty()) currentRoomIndex = 0;
        }
        updateGuildVisibility();
        updateGuildUI();
    }

    private void setupUI() {
        setTitle("QuestGuild - RPG Planner");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(650, 750);
        setLayout(new BorderLayout());

        topSplitPanel = new JPanel();
        myPanel = new JPanel(new BorderLayout());
        myPanel.setBorder(BorderFactory.createTitledBorder("내 캐릭터"));

        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setPreferredSize(new Dimension(140, 140));

        JPanel statsPanel = new JPanel(new GridLayout(3, 1));
        statusLabel = new JLabel();
        statusLabel.setFont(new Font("SansSerif", Font.BOLD, 15));

        totalCompletedLabel = new JLabel();
        totalCompletedLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        totalCompletedLabel.setForeground(new Color(150, 200, 150));

        expBar = new JProgressBar(0, 100);
        expBar.setStringPainted(true);

        statsPanel.add(statusLabel);
        statsPanel.add(totalCompletedLabel);
        statsPanel.add(expBar);

        myPanel.add(imageLabel, BorderLayout.WEST);
        myPanel.add(statsPanel, BorderLayout.CENTER);

        guildContainer = new JPanel(new BorderLayout());
        guildContainer.setBorder(BorderFactory.createTitledBorder("길드 현황"));

        JPanel guildHeaderPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton prevGuildBtn = new JButton("◀");
        guildNameLabel = new JLabel("가입한 길드 없음", SwingConstants.CENTER);
        guildNameLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        JButton nextGuildBtn = new JButton("▶");

        prevGuildBtn.addActionListener(e -> cycleGuild(-1));
        nextGuildBtn.addActionListener(e -> cycleGuild(1));

        guildHeaderPanel.add(prevGuildBtn);
        guildHeaderPanel.add(guildNameLabel);
        guildHeaderPanel.add(nextGuildBtn);

        partyPanel = new JPanel();
        partyPanel.setLayout(new BoxLayout(partyPanel, BoxLayout.Y_AXIS));

        JButton leaveGuildBtn = new JButton("탈퇴/해산");
        leaveGuildBtn.addActionListener(e -> leaveCurrentGuild());

        guildContainer.add(guildHeaderPanel, BorderLayout.NORTH);
        guildContainer.add(new JScrollPane(partyPanel), BorderLayout.CENTER);
        guildContainer.add(leaveGuildBtn, BorderLayout.SOUTH);

        topSplitPanel.setLayout(new GridLayout(1, 1));
        topSplitPanel.add(myPanel);

        updateStatus();
        add(topSplitPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        JPanel centerTopPanel = new JPanel(new BorderLayout());

        JPanel dateNavPanel = new JPanel(new FlowLayout());
        JButton btnPrev = new JButton("◀");
        dateLabel = new JLabel(currentDate.toString());
        dateLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        JButton btnNext = new JButton("▶");
        JButton btnCalendar = new JButton("📅");

        btnPrev.addActionListener(e -> { currentDate = currentDate.minusDays(1); renderQuests(); });
        btnNext.addActionListener(e -> { currentDate = currentDate.plusDays(1); renderQuests(); });
        btnCalendar.addActionListener(e -> {
            DatePickerDialog dp = new DatePickerDialog(this, currentDate, quests);
            dp.setVisible(true);
            if (dp.getSelectedDate() != null) {
                currentDate = dp.getSelectedDate();
                renderQuests();
            }
        });

        dateNavPanel.add(btnPrev);
        dateNavPanel.add(dateLabel);
        dateNavPanel.add(btnNext);
        dateNavPanel.add(btnCalendar);

        JPanel addQuestPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        btnRebirth = new JButton("✨ 새로운 알 받기");
        btnRebirth.setBackground(new Color(255, 215, 0));
        btnRebirth.setForeground(Color.BLACK);
        btnRebirth.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnRebirth.setVisible(false);
        btnRebirth.addActionListener(e -> checkAndProcessRebirth(0));

        JButton btnAddQuest = new JButton("➕ 현재 날짜에 할 일 추가");
        btnAddQuest.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnAddQuest.setBackground(new Color(50, 120, 70));
        btnAddQuest.setForeground(Color.WHITE);
        btnAddQuest.addActionListener(e -> addQuest());

        addQuestPanel.add(btnRebirth);
        addQuestPanel.add(btnAddQuest);

        centerTopPanel.add(dateNavPanel, BorderLayout.NORTH);
        centerTopPanel.add(addQuestPanel, BorderLayout.SOUTH);
        centerPanel.add(centerTopPanel, BorderLayout.NORTH);

        JPanel questContainer = new JPanel(new GridLayout(2, 1));

        todoPanel = new JPanel();
        todoPanel.setLayout(new BoxLayout(todoPanel, BoxLayout.Y_AXIS));
        JScrollPane todoScroll = new JScrollPane(todoPanel);
        todoScroll.setBorder(BorderFactory.createTitledBorder("🔥 할 일"));

        completedPanel = new JPanel();
        completedPanel.setLayout(new BoxLayout(completedPanel, BoxLayout.Y_AXIS));
        JScrollPane compScroll = new JScrollPane(completedPanel);
        compScroll.setBorder(BorderFactory.createTitledBorder("✅ 완료된 퀘스트"));

        questContainer.add(todoScroll);
        questContainer.add(compScroll);
        centerPanel.add(questContainer, BorderLayout.CENTER);

        summaryLabel = new JLabel("🏆 완료 퀘스트 - 오늘: 0개 | 이번 주: 0개 | 이번 달: 0개", SwingConstants.CENTER);
        summaryLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
        summaryLabel.setForeground(new Color(150, 200, 150));

        JPanel summaryPanel = new JPanel(new BorderLayout());
        summaryPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        summaryPanel.add(summaryLabel, BorderLayout.CENTER);

        centerPanel.add(summaryPanel, BorderLayout.SOUTH);
        add(centerPanel, BorderLayout.CENTER);

        JButton menuButton = new JButton("메뉴 ☰");
        menuButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        menuButton.setPreferredSize(new Dimension(0, 50));
        menuButton.addActionListener(e -> showMenu());
        add(menuButton, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    private void updateGuildVisibility() {
        topSplitPanel.removeAll();
        if (roomCodesList.isEmpty()) {
            topSplitPanel.setLayout(new GridLayout(1, 1));
            topSplitPanel.add(myPanel);
        } else {
            topSplitPanel.setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.BOTH;
            gbc.weighty = 1.0;

            gbc.weightx = 0.65;
            gbc.gridx = 0;
            topSplitPanel.add(myPanel, gbc);

            gbc.weightx = 0.35;
            gbc.gridx = 1;
            topSplitPanel.add(guildContainer, gbc);
        }
        topSplitPanel.revalidate();
        topSplitPanel.repaint();
    }

    private void updateStatus() {
        int level = player.getLevel();
        String type = player.getCharacterType();
        String emoji = "🥚";
        String imgFileName = "egg.png";
        String statusText = "";

        if ("EGG".equals(type)) {
            if (level >= 10) { emoji = "🥚"; imgFileName = "egg_crack_2.png"; statusText = "알 (많이 금 감)"; }
            else if (level >= 5) { emoji = "🥚"; imgFileName = "egg_crack_1.png"; statusText = "알 (살짝 금 감)"; }
            else { emoji = "🥚"; imgFileName = "egg.png"; statusText = "알"; }
        } else {
            if (level < 15) {
                showEventDialog("Oh No!", "경험치를 잃어 다시 알로 돌아갔습니다...");
                player.getUnlockedCollection().remove(type + "_1");
                player.setCharacterType("EGG");
                updateStatus();
                return;
            }
            statusText = type;
            int stage = 1;
            if (level >= 50) stage = 4;
            else if (level >= 40) stage = 3;
            else if (level >= 25) stage = 2;
            else stage = 1;

            for (int i = stage + 1; i <= 4; i++) player.getUnlockedCollection().remove(type + "_" + i);
            player.getUnlockedCollection().add(type + "_" + stage);

            switch (type) {
                case "DRAGON": if (stage == 4) { emoji = "🐉"; imgFileName = "dragon_stage4.png"; statusText += " (최종형)"; } else if (stage == 3) { emoji = "🐊"; imgFileName = "dragon_stage3.png"; statusText += " (청년기)"; } else if (stage == 2) { emoji = "🐍"; imgFileName = "dragon_stage2.png"; statusText += " (유년기)"; } else { emoji = "🐣"; imgFileName = "dragon_stage1.png"; statusText += " (탄생)"; } break;
                case "EAGLE": if (stage == 4) { emoji = "🦅"; imgFileName = "eagle_stage4.png"; statusText += " (최종형)"; } else if (stage == 3) { emoji = "🐦"; imgFileName = "eagle_stage3.png"; statusText += " (청년기)"; } else if (stage == 2) { emoji = "🐤"; imgFileName = "eagle_stage2.png"; statusText += " (유년기)"; } else { emoji = "🐣"; imgFileName = "eagle_stage1.png"; statusText += " (탄생)"; } break;
                case "WOLF": if (stage == 4) { emoji = "🐺"; imgFileName = "wolf_stage4.png"; statusText += " (최종형)"; } else if (stage == 3) { emoji = "🐕"; imgFileName = "wolf_stage3.png"; statusText += " (청년기)"; } else if (stage == 2) { emoji = "🐶"; imgFileName = "wolf_stage2.png"; statusText += " (유년기)"; } else { emoji = "🐾"; imgFileName = "wolf_stage1.png"; statusText += " (탄생)"; } break;
                case "LION": if (stage == 4) { emoji = "🦁"; imgFileName = "lion_stage4.png"; statusText += " (최종형)"; } else if (stage == 3) { emoji = "🐅"; imgFileName = "lion_stage3.png"; statusText += " (청년기)"; } else if (stage == 2) { emoji = "🐯"; imgFileName = "lion_stage2.png"; statusText += " (유년기)"; } else { emoji = "🐱"; imgFileName = "lion_stage1.png"; statusText += " (탄생)"; } break;
                case "WATER": if (stage == 4) { emoji = "🧜"; imgFileName = "water_stage4.png"; statusText += " (최종형)"; } else if (stage == 3) { emoji = "🌊"; imgFileName = "water_stage3.png"; statusText += " (청년기)"; } else if (stage == 2) { emoji = "💦"; imgFileName = "water_stage2.png"; statusText += " (유년기)"; } else { emoji = "💧"; imgFileName = "water_stage1.png"; statusText += " (탄생)"; } break;
            }
        }

        String rebirthText = player.getRebirthCount() > 0 ? "<br><font color='#FFD700' size='3'>✨ 환생 " + player.getRebirthCount() + "회차</font>" : "";
        statusLabel.setText("<html>LV." + level + " " + player.getNickname() + " [" + statusText + "]" + rebirthText + "</html>");

        long totalCompleted = quests.stream().filter(Quest::isCompleted).count();
        totalCompletedLabel.setText("🏆 총 달성 퀘스트: " + totalCompleted + "개");
        expBar.setValue((int) player.getExpPercentage());
        expBar.setString(String.format("%d / %d (%.1f%%)", player.getCurrentExp(), player.getRequiredExp(), player.getExpPercentage()));

        File imgFile = new File("images/" + imgFileName);
        if (imgFile.exists()) {
            ImageIcon icon = new ImageIcon(imgFile.getAbsolutePath());
            Image scaled = icon.getImage().getScaledInstance(125, 125, Image.SCALE_SMOOTH);
            imageLabel.setIcon(new ImageIcon(scaled));
            imageLabel.setText("");
        } else {
            imageLabel.setIcon(null);
            imageLabel.setText(emoji);
            imageLabel.setFont(new Font("SansSerif", Font.PLAIN, 85));
        }

        if (btnRebirth != null) btnRebirth.setVisible(player.getLevel() >= 50 && !"EGG".equals(player.getCharacterType()));
    }

    private void updateStatsSummary() {
        LocalDate today = LocalDate.now();
        int dailyCount = 0; int weeklyCount = 0; int monthlyCount = 0;
        int dayOfWeekValue = today.getDayOfWeek().getValue();
        LocalDate startOfWeek = today.minusDays(dayOfWeekValue - 1);
        LocalDate endOfWeek = startOfWeek.plusDays(6);

        for (Quest q : quests) {
            if (q.isCompleted()) {
                try {
                    LocalDate qDate = LocalDate.parse(q.getDate());
                    if (qDate.equals(today)) dailyCount++;
                    if (!qDate.isBefore(startOfWeek) && !qDate.isAfter(endOfWeek)) weeklyCount++;
                    if (qDate.getYear() == today.getYear() && qDate.getMonth() == today.getMonth()) monthlyCount++;
                } catch (Exception e) {}
            }
        }
        summaryLabel.setText(String.format("🏆 완료 퀘스트 - 오늘: %d개 | 이번 주: %d개 | 이번 달: %d개", dailyCount, weeklyCount, monthlyCount));
    }

    private void showMenu() {
        JDialog menuDialog = new JDialog(this, "길드 메뉴", true);
        menuDialog.setLayout(new BorderLayout());

        JLabel msgLabel = new JLabel("수행할 동작을 선택하세요.", SwingConstants.CENTER);
        msgLabel.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        msgLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        menuDialog.add(msgLabel, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));

        JButton btn1 = new JButton("할 일 반복 추가");
        JButton btn2 = new JButton("캐릭터 도감 보기");
        JButton btn3 = new JButton("방 참가/생성");
        JButton btn4 = new JButton("로그아웃");
        JButton btn5 = new JButton("계정 삭제");
        JButton btn6 = new JButton("닫기");

        btn1.addActionListener(e -> { menuDialog.dispose(); addRepeatQuest(); });
        btn2.addActionListener(e -> { menuDialog.dispose(); showCollection(); });
        btn3.addActionListener(e -> { menuDialog.dispose(); showJoinDialog(); });
        btn4.addActionListener(e -> { menuDialog.dispose(); logout(); });
        btn5.addActionListener(e -> { menuDialog.dispose(); deleteAccount(); });
        btn6.addActionListener(e -> menuDialog.dispose());

        btnPanel.add(btn1); btnPanel.add(btn2); btnPanel.add(btn3);
        btnPanel.add(btn4); btnPanel.add(btn5); btnPanel.add(btn6);

        menuDialog.add(btnPanel, BorderLayout.CENTER);
        menuDialog.pack();
        menuDialog.setLocationRelativeTo(this);
        menuDialog.setVisible(true);
    }

    private void closeAllConnections() {
        for (SocialClient client : activeClients.values()) {
            client.disconnect();
        }
        activeClients.clear();
    }

    private void logout() {
        if (JOptionPane.showConfirmDialog(this, "정말 로그아웃 하시겠습니까?", "로그아웃", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try { Thread.sleep(200); } catch(Exception e){} // 메시지 전송 대기시간
            closeAllConnections();
            dispose();
            SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
        }
    }

    private void deleteAccount() {
        if (JOptionPane.showConfirmDialog(this, "정말 계정을 삭제하시겠습니까?\n모든 도감과 퀘스트 데이터가 영구적으로 삭제됩니다!", "⚠️ 계정 삭제 경고", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {

            List<String> codesToProcess = new ArrayList<>(roomCodesList);
            for (String code : codesToProcess) {
                String name = player.getJoinedRooms().get(code).replace(" (방장)", "");
                boolean amIHost = isHost(code);

                if (amIHost) {
                    Map<String, GameData> members = new HashMap<>(multiRoomMembers.getOrDefault(code, new HashMap<>()));
                    members.remove(player.getNickname());

                    if (members.isEmpty()) {
                        activeClients.get(code).sendStatus(code, player, "DISBAND", true);
                    } else {
                        String[] options = {"방장 양보하고 계정 삭제", "길드 강제 해산", "계정 삭제 취소"};
                        int choice = JOptionPane.showOptionDialog(this, "[" + name + "] 길드의 방장입니다!\n탈퇴 전 어떻게 할까요?", "길드 방장 권한 처리", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]);

                        if (choice == 0) {
                            String[] memberNames = members.keySet().toArray(new String[0]);
                            String selected = (String) JOptionPane.showInputDialog(this, "방장을 넘겨줄 길드원을 선택하세요:", "방장 위임", JOptionPane.QUESTION_MESSAGE, null, memberNames, memberNames[0]);
                            if (selected != null) {
                                activeClients.get(code).sendStatus(code, player, "TRANSFER:" + selected, false);
                                activeClients.get(code).sendStatus(code, player, "LEAVE", false);
                            } else {
                                return;
                            }
                        } else if (choice == 1) {
                            activeClients.get(code).sendStatus(code, player, "DISBAND", true);
                        } else {
                            return;
                        }
                    }
                } else {
                    activeClients.get(code).sendStatus(code, player, "LEAVE", false);
                }
            }

            try { Thread.sleep(300); } catch(Exception e){} // 메시지가 서버에 도달하도록 잠깐 대기
            closeAllConnections();
            new File(SAVE_FILE).delete();
            JOptionPane.showMessageDialog(this, "계정이 성공적으로 삭제되었습니다.");
            dispose();
            SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
        }
    }

    private void showCollection() {
        new CollectionDialog(this, player.getUnlockedCollection()).setVisible(true);
    }

    private void addQuest() {
        if (player.getLevel() >= 50 && !"EGG".equals(player.getCharacterType()) && checkAndProcessRebirth(0)) return;

        JTextField titleField = new JTextField(15);
        JTextField pointField = new JTextField("20", 5);
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        panel.add(new JLabel("할 일 내용:")); panel.add(titleField);
        panel.add(new JLabel("획득 포인트:")); panel.add(pointField);

        if (JOptionPane.showConfirmDialog(this, panel, "[" + currentDate.toString() + "] 계획 추가", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            String title = titleField.getText().trim();
            if (!title.isEmpty()) {
                int point = 20; try { point = Integer.parseInt(pointField.getText().trim()); } catch (Exception e) { }
                quests.add(new Quest(title, currentDate.toString(), point));
                saveGameData(); renderQuests();
            }
        }
    }

    private void addRepeatQuest() {
        if (player.getLevel() >= 50 && !"EGG".equals(player.getCharacterType()) && checkAndProcessRebirth(0)) return;

        JTextField titleField = new JTextField(15);
        JTextField pointField = new JTextField("20", 5);
        JTextField daysField = new JTextField("7", 5);
        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        panel.add(new JLabel("할 일 내용:")); panel.add(titleField);
        panel.add(new JLabel("획득 포인트:")); panel.add(pointField);
        panel.add(new JLabel("반복 일수 (오늘부터):")); panel.add(daysField);

        if (JOptionPane.showConfirmDialog(this, panel, "할 일 반복 추가", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            String title = titleField.getText().trim();
            if (!title.isEmpty()) {
                int point = 20; int days = 7;
                try { point = Integer.parseInt(pointField.getText().trim()); days = Integer.parseInt(daysField.getText().trim()); } catch (Exception e) {}
                for (int i = 0; i < days; i++) quests.add(new Quest(title, currentDate.plusDays(i).toString(), point));
                saveGameData(); renderQuests();
                JOptionPane.showMessageDialog(this, days + "일 동안의 반복 퀘스트가 등록되었습니다!");
            }
        }
    }

    private void cycleGuild(int direction) {
        if (roomCodesList.isEmpty()) return;
        currentRoomIndex += direction;
        if (currentRoomIndex >= roomCodesList.size()) currentRoomIndex = 0;
        else if (currentRoomIndex < 0) currentRoomIndex = roomCodesList.size() - 1;
        updateGuildUI();
    }

    private int connectToRoom(String code, String roomName, String mode, boolean isHostMode) {
        SocialClient client = new SocialClient();
        java.util.function.Consumer<GameData> onData = data -> SwingUtilities.invokeLater(() -> {
            String cmd = data.getCommand();
            String sender = data.getSenderNickname();

            if ("JOIN".equals(cmd) || "UPDATE".equals(cmd)) {
                multiRoomMembers.computeIfAbsent(code, k -> new HashMap<>()).put(sender, data);

                // ✨ 내가 오프라인일 때 방장이 넘겨준 권한을 뒤늦게 깨달았을 때!
                if (sender.equals(player.getNickname()) && data.isHost() && !isHost(code)) {
                    String currentName = player.getJoinedRooms().get(code).replace(" (방장)","");
                    player.getJoinedRooms().put(code, currentName + " (방장)");
                    saveGameData();
                    JOptionPane.showMessageDialog(this, "🎉 오프라인 상태에서 [" + currentName + "] 길드의 방장 권한을 위임받았습니다!");
                    client.sendStatus(code, player, "UPDATE", true);
                } else if ("JOIN".equals(cmd)) {
                    client.sendStatus(code, player, "UPDATE", isHost(code));
                }
            } else if ("LEAVE".equals(cmd)) {
                if (multiRoomMembers.containsKey(code)) multiRoomMembers.get(code).remove(sender);
            } else if ("DISBAND".equals(cmd)) {
                JOptionPane.showMessageDialog(this, "방장이 길드 [" + roomName.replace(" (방장)","") + "] 를 해산했습니다.");
                removeGuildLocal(code);
            } else if (cmd != null && cmd.startsWith("TRANSFER:")) {
                String newHost = cmd.substring(9);
                if (newHost.equals(player.getNickname())) {
                    JOptionPane.showMessageDialog(this, "길드 방장을 위임받았습니다! 이제 당신이 방장입니다.");
                    player.getJoinedRooms().put(code, roomName.replace(" (방장)","") + " (방장)");
                    saveGameData();
                    client.sendStatus(code, player, "UPDATE", true);
                } else {
                    if (multiRoomMembers.containsKey(code) && multiRoomMembers.get(code).containsKey(newHost)) {
                        multiRoomMembers.get(code).get(newHost).setHost(true);
                    }
                }
            }
            if (!roomCodesList.isEmpty() && code.equals(roomCodesList.get(currentRoomIndex))) {
                updateGuildUI();
            }
        });

        int status = client.connect(code, player, onData, mode, isHostMode);
        if (status == 1) activeClients.put(code, client);
        return status;
    }

    private void showJoinDialog() {
        JoinDialog dialog = new JoinDialog(this);
        dialog.setVisible(true);
    }

    public boolean processJoin(String roomName, String password, boolean isCreate) {
        String code = password.isEmpty() ? roomName : roomName + "_[PW:" + password + "]";

        if (player.getJoinedRooms().containsKey(code)) {
            JOptionPane.showMessageDialog(this, "이미 참가한 길드입니다.", "참가 불가", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        int status = connectToRoom(code, roomName, isCreate ? "CREATE" : "JOIN", isCreate);

        if (isCreate) {
            if (status == 0) {
                JOptionPane.showMessageDialog(this, "이미 존재하는 방 이름입니다.", "생성 불가", JOptionPane.ERROR_MESSAGE);
                return false;
            } else if (status == -1) {
                new Thread(() -> org.example.network.SocialServer.main(null)).start();
                try { Thread.sleep(500); } catch (InterruptedException ex) {}
                status = connectToRoom(code, roomName, "CREATE", true);
                if (status != 1) {
                    JOptionPane.showMessageDialog(this, "방 서버를 여는 데 실패했습니다.", "오류", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            }
            roomName += " (방장)";
            addGuildLocal(code, roomName);
            JOptionPane.showMessageDialog(this, "방 [" + roomName + "] 생성 및 참가 완료!");
            return true;
        } else {
            if (status == 0) {
                JOptionPane.showMessageDialog(this, "존재하지 않는 방이거나 비밀번호가 틀렸습니다.", "참가 실패", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            else if (status == -1) {
                JOptionPane.showMessageDialog(this, "서버가 닫혀있습니다.", "참가 실패", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            addGuildLocal(code, roomName);
            JOptionPane.showMessageDialog(this, "방 [" + roomName + "] 에 참가했습니다!");
            return true;
        }
    }

    private void addGuildLocal(String code, String roomName) {
        player.getJoinedRooms().put(code, roomName);
        if (!roomCodesList.contains(code)) roomCodesList.add(code);
        currentRoomIndex = roomCodesList.size() - 1;
        updateAndSync();
        updateGuildVisibility();
        updateGuildUI();
    }

    private void removeGuildLocal(String code) {
        player.getJoinedRooms().remove(code);
        roomCodesList.remove(code);

        SocialClient client = activeClients.remove(code);
        if (client != null) {
            try { Thread.sleep(100); } catch(Exception e){} // 끊기 전 메시지 전송 보장
            client.disconnect();
        }

        multiRoomMembers.remove(code);
        currentRoomIndex = roomCodesList.isEmpty() ? -1 : 0;
        updateAndSync();
        updateGuildVisibility();
        updateGuildUI();
    }

    private void leaveCurrentGuild() {
        if (roomCodesList.isEmpty()) return;
        String code = roomCodesList.get(currentRoomIndex);
        String name = player.getJoinedRooms().get(code).replace(" (방장)", "");
        boolean amIHost = isHost(code);

        if (amIHost) {
            Map<String, GameData> members = new HashMap<>(multiRoomMembers.getOrDefault(code, new HashMap<>()));
            members.remove(player.getNickname());

            if (members.isEmpty()) {
                if (JOptionPane.showConfirmDialog(this, "길드원 없이 혼자 있는 방입니다. 방을 삭제하시겠습니까?", "길드 삭제", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    activeClients.get(code).sendStatus(code, player, "DISBAND", true);
                    removeGuildLocal(code);
                }
            } else {
                String[] options = {"방장 양보하고 탈퇴", "길드 강제 해산", "취소"};
                int choice = JOptionPane.showOptionDialog(this, "당신은 방장입니다! 탈퇴 시 어떻게 할까요?", "길드 탈퇴", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]);

                if (choice == 0) {
                    String[] memberNames = members.keySet().toArray(new String[0]);
                    String selected = (String) JOptionPane.showInputDialog(this, "방장을 넘겨줄 길드원을 선택하세요:", "방장 위임", JOptionPane.QUESTION_MESSAGE, null, memberNames, memberNames[0]);
                    if (selected != null) {
                        activeClients.get(code).sendStatus(code, player, "TRANSFER:" + selected, false);
                        activeClients.get(code).sendStatus(code, player, "LEAVE", false);
                        removeGuildLocal(code);
                        JOptionPane.showMessageDialog(this, "성공적으로 권한을 위임하고 길드에서 탈퇴했습니다.");
                    }
                } else if (choice == 1) {
                    activeClients.get(code).sendStatus(code, player, "DISBAND", true);
                    removeGuildLocal(code);
                    JOptionPane.showMessageDialog(this, "길드가 성공적으로 해산되었습니다.");
                }
            }
        } else {
            if (JOptionPane.showConfirmDialog(this, "[" + name + "] 길드에서 탈퇴하시겠습니까?", "길드 탈퇴", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                activeClients.get(code).sendStatus(code, player, "LEAVE", false);
                removeGuildLocal(code);
            }
        }
    }

    private void updateGuildUI() {
        if (roomCodesList.isEmpty()) {
            guildNameLabel.setText("가입한 길드 없음");
            partyPanel.removeAll(); partyPanel.revalidate(); partyPanel.repaint();
            return;
        }

        if (currentRoomIndex >= roomCodesList.size() || currentRoomIndex < 0) currentRoomIndex = 0;

        String currentCode = roomCodesList.get(currentRoomIndex);
        String roomName = player.getJoinedRooms().get(currentCode);
        guildNameLabel.setText(roomName != null ? roomName.replace(" (방장)","") : "알 수 없는 길드");

        partyPanel.removeAll();

        Map<String, GameData> currentMembers = new HashMap<>(multiRoomMembers.getOrDefault(currentCode, new HashMap<>()));
        currentMembers.remove(player.getNickname());

        List<GameData> sortedMembers = new ArrayList<>(currentMembers.values());

        GameData me = new GameData();
        me.setSenderNickname(player.getNickname());
        me.setLevel(player.getLevel());
        me.setExpPercentage(player.getExpPercentage());
        me.setHost(isHost(currentCode));
        me.setRebirthCount(player.getRebirthCount());
        sortedMembers.add(me);

        sortedMembers.sort((a, b) -> {
            if (a.isHost() && !b.isHost()) return -1;
            if (!a.isHost() && b.isHost()) return 1;
            return Integer.compare(b.getLevel(), a.getLevel());
        });

        for (GameData member : sortedMembers) {
            boolean isMe = member.getSenderNickname().equals(player.getNickname());

            String meTag = isMe ? " (나)" : "";
            String hostTag = member.isHost() ? " 👑[방장]" : "";
            String rebirthTag = member.getRebirthCount() > 0 ? "[환생 " + member.getRebirthCount() + "회] " : "";

            String displayText = rebirthTag + "Lv." + member.getLevel() + " " + member.getSenderNickname() + meTag + " (" + String.format("%.1f", member.getExpPercentage()) + "%)" + hostTag;
            JLabel lbl = new JLabel(displayText);

            if (isMe) {
                lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
                lbl.setForeground(new Color(255, 215, 0));
            } else {
                lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
                lbl.setForeground(new Color(100, 200, 255));
            }
            partyPanel.add(lbl);
        }

        partyPanel.revalidate(); partyPanel.repaint();
    }

    private void renderQuests() {
        dateLabel.setText(currentDate.toString());
        todoPanel.removeAll();
        completedPanel.removeAll();

        for (Quest q : quests) {
            if (q.getDate().equals(currentDate.toString())) {
                JCheckBox checkBox = new JCheckBox(q.getTitle() + " (" + q.getPoint() + " EXP)");
                checkBox.setSelected(q.isCompleted());

                checkBox.addActionListener(e -> {
                    if (checkBox.isSelected()) {
                        q.setCompleted(true); handleExpGain(q.getPoint());
                    } else {
                        q.setCompleted(false); handleExpLoss(q.getPoint());
                    }
                    renderQuests();
                });
                if (q.isCompleted()) completedPanel.add(checkBox);
                else todoPanel.add(checkBox);
            }
        }
        updateStatsSummary();
        todoPanel.revalidate(); todoPanel.repaint();
        completedPanel.revalidate(); completedPanel.repaint();
    }

    private void handleExpGain(int amount) {
        int oldLevel = player.getLevel();
        if (oldLevel >= 50 && !"EGG".equals(player.getCharacterType())) {
            if (!checkAndProcessRebirth(amount)) updateAndSync();
            return;
        }
        player.addExp(amount);
        if (player.getLevel() > oldLevel) checkHatchingOrGrowth(oldLevel);
        updateAndSync();

        if (oldLevel < 50 && player.getLevel() == 50) {
            showEventDialog("👑 만렙 달성! 전설 등극 👑", "최종 형태에 도달했습니다! 당분간 멋진 모습을 감상하세요.\n(다음 퀘스트 완료 시 환생하거나, '새로운 알 받기' 버튼을 누르세요.)");
        }
    }

    private boolean checkAndProcessRebirth(int pendingExp) {
        if (JOptionPane.showConfirmDialog(this, "전설에 도달한 " + player.getNickname() + "님!\n현재 캐릭터를 명예의 전당에 등록하고,\n새로운 전설을 시작하기 위해 '신비한 알'을 받으시겠습니까?", "길드 환생 시스템", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            player.setLevel(1); player.setCurrentExp(0); player.setCharacterType("EGG");
            player.setRebirthCount(player.getRebirthCount() + 1);
            if (pendingExp > 0) player.addExp(pendingExp);
            updateAndSync(); renderQuests();
            JOptionPane.showMessageDialog(this, "새로운 '신비한 알'을 획득했습니다! 다시 모험을 시작하세요.", "모험 재시작", JOptionPane.PLAIN_MESSAGE);
            return true;
        }
        return false;
    }

    private void checkHatchingOrGrowth(int oldLevel) {
        int newLevel = player.getLevel();
        if (oldLevel < 15 && newLevel >= 15 && "EGG".equals(player.getCharacterType())) {
            String[] possibleTypes = {"DRAGON", "EAGLE", "WOLF", "LION", "WATER"};
            String chosenType = possibleTypes[new Random().nextInt(possibleTypes.length)];
            player.setCharacterType(chosenType);
            showEventDialog("⚡ 탄생 완료! ⚡", "축하합니다! 당신의 곁에 [" + chosenType + "] (이)가 찾아왔습니다!");
        }
        else if (oldLevel < 5 && newLevel >= 5 && "EGG".equals(player.getCharacterType())) showEventDialog("🥚...?", "알에 미세한 금이 가기 시작했습니다! (살짝 금감)");
        else if (oldLevel < 10 && newLevel >= 10 && "EGG".equals(player.getCharacterType())) showEventDialog("🥚!!", "금이 더 넓게 퍼지기 시작했습니다! 부화가 머지않았습니다! (많이 금감)");
        else if (!"EGG".equals(player.getCharacterType())) {
            if (oldLevel < 25 && newLevel >= 25) showEventDialog("✨ 성장! ✨", "당신의 [" + player.getCharacterType() + "](이)가 유년기로 성장했습니다!");
            else if (oldLevel < 40 && newLevel >= 40) showEventDialog("⚔️ 각성! ⚔️", "당신의 [" + player.getCharacterType() + "](이)가 늠름한 청년기로 성장했습니다!");
        }
    }

    private void showEventDialog(String title, String message) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel(title, SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 26));
        label.setForeground(new Color(255, 215, 0));
        panel.add(label, BorderLayout.CENTER);
        panel.add(new JLabel(message, SwingConstants.CENTER), BorderLayout.SOUTH);
        JOptionPane.showMessageDialog(this, panel, "모험의 이정표", JOptionPane.PLAIN_MESSAGE);
    }

    private void handleExpLoss(int amount) {
        player.removeExp(amount);
        updateAndSync();
    }

    private void updateAndSync() {
        updateStatus();
        updateGuildUI();
        saveGameData();
        for (Map.Entry<String, SocialClient> entry : activeClients.entrySet()) {
            entry.getValue().sendStatus(entry.getKey(), player, "UPDATE", isHost(entry.getKey()));
        }
    }

    public static void main(String[] args) {
        FlatDarkLaf.setup();
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}