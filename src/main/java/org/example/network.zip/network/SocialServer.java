package org.example.network;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class SocialServer {
    private static final int PORT = 9999;
    public static final Map<String, List<ClientHandler>> rooms = new ConcurrentHashMap<>();
    public static final Map<String, Map<String, String>> roomRosters = new ConcurrentHashMap<>();

    // ✨ 신규: 완전히 해산(폭파)된 방 코드를 영구적으로 기억하는 블랙리스트!
    public static final Set<String> disbandedRooms = ConcurrentHashMap.newKeySet();

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("길드 서버가 시작되었습니다. 포트: " + PORT);
            while (true) {
                Socket socket = serverSocket.accept();
                new ClientHandler(socket).start();
            }
        } catch (IOException e) {
            System.out.println("서버가 이미 실행 중입니다.");
        }
    }
}

class ClientHandler extends Thread {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String roomCode;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);

            String handshake = in.readLine();
            if (handshake == null) return;

            if (handshake.startsWith("CREATE:")) {
                roomCode = handshake.substring(7);
                // 블랙리스트에 있거나 이미 존재하는 방이면 거절
                if (SocialServer.rooms.containsKey(roomCode) || SocialServer.disbandedRooms.contains(roomCode)) {
                    out.println("FAIL"); return;
                } else {
                    SocialServer.rooms.put(roomCode, new CopyOnWriteArrayList<>());
                    SocialServer.roomRosters.put(roomCode, new ConcurrentHashMap<>());
                    SocialServer.rooms.get(roomCode).add(this);
                    out.println("SUCCESS");
                }
            }
            else if (handshake.startsWith("JOIN:")) {
                roomCode = handshake.substring(5);
                if (!SocialServer.rooms.containsKey(roomCode)) {
                    out.println("FAIL"); return;
                } else {
                    SocialServer.rooms.get(roomCode).add(this);
                    out.println("SUCCESS");

                    Map<String, String> roster = SocialServer.roomRosters.get(roomCode);
                    if (roster != null) {
                        for (String userData : roster.values()) out.println(userData);
                    }
                }
            }
            else if (handshake.startsWith("RECONNECT:")) {
                roomCode = handshake.substring(10);

                // ✨ 좀비 방 방지: 해산된 방에 들어오려고 하면 거절!
                if (SocialServer.disbandedRooms.contains(roomCode)) {
                    out.println("DISBANDED");
                    return;
                }

                SocialServer.rooms.putIfAbsent(roomCode, new CopyOnWriteArrayList<>());
                SocialServer.roomRosters.putIfAbsent(roomCode, new ConcurrentHashMap<>());
                SocialServer.rooms.get(roomCode).add(this);
                out.println("SUCCESS");

                Map<String, String> roster = SocialServer.roomRosters.get(roomCode);
                if (roster != null) {
                    for (String userData : roster.values()) out.println(userData);
                }
            }
            else {
                out.println("FAIL"); return;
            }

            String message;
            while ((message = in.readLine()) != null) {
                String sender = "";
                try { sender = message.split("\"senderNickname\":\"")[1].split("\"")[0]; } catch (Exception e) {}

                if (message.contains("\"command\":\"DISBAND\"")) {
                    SocialServer.rooms.remove(roomCode);
                    SocialServer.roomRosters.remove(roomCode);
                    SocialServer.disbandedRooms.add(roomCode); // ✨ 블랙리스트에 추가
                } else if (message.contains("\"command\":\"LEAVE\"")) {
                    if (!sender.isEmpty() && SocialServer.roomRosters.containsKey(roomCode)) {
                        SocialServer.roomRosters.get(roomCode).remove(sender);
                    }
                } else if (message.contains("\"command\":\"TRANSFER:")) {
                    // ✨ 오프라인 위임 로직: 서버가 방명록의 데이터를 강제로 '방장'으로 뜯어고칩니다!
                    String newHost = message.split("TRANSFER:")[1].split("\"")[0];
                    if (SocialServer.roomRosters.containsKey(roomCode)) {
                        Map<String, String> roster = SocialServer.roomRosters.get(roomCode);
                        if (roster.containsKey(newHost)) {
                            String oldJson = roster.get(newHost);
                            String newJson = oldJson.replace("\"host\":false", "\"host\":true").replace("\"isHost\":false", "\"isHost\":true");
                            roster.put(newHost, newJson);
                        }
                    }
                } else {
                    if (!sender.isEmpty() && SocialServer.roomRosters.containsKey(roomCode)) {
                        SocialServer.roomRosters.get(roomCode).put(sender, message);
                    }
                }
                broadcast(message);
            }
        } catch (IOException e) {
        } finally {
            if (roomCode != null && SocialServer.rooms.containsKey(roomCode)) {
                SocialServer.rooms.get(roomCode).remove(this);
            }
            try { socket.close(); } catch (IOException e) {}
        }
    }

    private void broadcast(String message) {
        List<ClientHandler> clients = SocialServer.rooms.get(roomCode);
        if (clients != null) {
            for (ClientHandler client : clients) {
                if (client != this) {
                    client.out.println(message);
                }
            }
        }
    }
}